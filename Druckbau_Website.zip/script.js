// Product Data
const products = [
    { id: 'a', name: 'Fidget Klicker', price: 3.99 },
    { id: 'b', name: 'Hundekotbeutelspender', price: 14.99, description: 'fasst 5 Beutel', images: ['hund_1.jpg', 'hund_2.jpg', 'hund_3.jpg', 'hund_4.jpg', 'hund_5.jpg'] },
    { id: 'c', name: 'Vase', price: 24.99, description: '20cm groß, Lochdurchmesser 2,5cm', images: ['vase_1.jpg', 'vase_2.jpg'] },
    { id: 'e', name: 'Stifthalter', price: 6.99, description: '10cm groß' },
    { id: 'd', name: 'Auftragsarbeit', price: 0, isCustom: true }
];

const colors = [
    { name: 'Cyan-Blau', value: 'blue' },
    { name: 'Weiss', value: 'white' },
    { name: 'Schwarz', value: 'black' },
    { name: 'Grün', value: 'green' },
    { name: 'Orange', value: 'orange' },
    { name: 'Transparent Blau', value: 'trans-blue' },
    { name: 'Transparent Grün', value: 'trans-green' },
    { name: 'Transparent Gelb', value: 'trans-yellow' },
    { name: 'Transparent Rot', value: 'trans-red' },
    { name: 'Grau', value: 'grey' },
    { name: 'Braun', value: 'brown' },
    { name: 'Eigene (Wunschfarbe)', value: 'custom' }
];

// Cart State
let cart = [];
const SHIPPING_COST = 4.90;

// Initializes the application
function init() {
    // Check if we are on the gallery page
    if (document.getElementById('gallery-app')) {
        loadGallery();
        return;
    }

    // Normal page initialization
    if (document.getElementById('products-grid')) {
        renderProducts();
        setupNavigation();
        updateCartIcon();
        setupColorPreviews();
    }
}

// Gallery Standalone Logic
function loadGallery() {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get('id');
    const startImg = params.get('img');

    const product = products.find(p => p.id === productId);

    if (!product || !product.images) {
        document.body.innerHTML = '<h1 style="color:white; text-align:center;">Produkt nicht gefunden</h1>';
        return;
    }

    document.getElementById('product-title').innerText = product.name;
    const mainImg = document.getElementById('main-display');
    const thumbsContainer = document.getElementById('thumbs-container');

    // Set initial image
    let currentImg = startImg || product.images[0];
    mainImg.src = currentImg;

    // Render thumbnails
    thumbsContainer.innerHTML = product.images.map(img => `
        <img src="${img}" class="thumbnail ${img === currentImg ? 'active' : ''}" onclick="switchGalleryImage('${img}', this)">
    `).join('');
}

window.switchGalleryImage = function (src, thumb) {
    document.getElementById('main-display').src = src;
    document.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
    thumb.classList.add('active');
}

// Render Products to DOM
function renderProducts() {
    const grid = document.getElementById('products-grid');
    grid.innerHTML = products.map(product => {
        if (product.isCustom) {
            return `
            <div class="product-card">
                <h3>${product.name}</h3>
                <span class="price">Individuell</span>
                
                <div class="product-options">
                    <div class="option-group">
                        <label>Von Wem (Schenkender/Auftraggeber):</label>
                        <input type="text" id="custom-from-${product.id}" placeholder="z.B. Ihr Name" class="qty-input">
                    
                    </div>
                    <div class="option-group">
                        <label>Für Wen (Empfänger/Widmung):</label>
                        <input type="text" id="custom-to-${product.id}" placeholder="z.B. Name des Beschenkten" class="qty-input">
                    </div>
                    <div class="option-group">
                        <label>Welcher Auftrag (Beschreibung/Idee):</label>
                        <textarea id="custom-desc-${product.id}" placeholder="Beschreiben Sie Ihre Idee oder was aufgedruckt werden soll..." class="qty-input" style="min-height: 60px;"></textarea>
                    </div>
                </div>

                <button class="add-btn" onclick="addCustomToCart('${product.id}')">
                    Auftrag hinzufügen
                </button>
            </div>
            `;
        }

        if (product.images && product.images.length > 0) {
            return `
            <div class="product-card">
                <h3>${product.name}</h3>
                <div class="gallery-container">
                <div class="gallery-slide" id="gallery-${product.id}">
                        ${product.images.map((img, i) => `
                        <div class="gallery-item" data-lightbox-src="${img}">
                            <img src="${img}" class="gallery-img">
                            <a href="gallery.html?id=${product.id}&img=${img}" target="_blank" class="maximize-icon" onclick="event.stopPropagation()">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M5.828 10.172a.5.5 0 0 0-.707 0l-4.096 4.096V11.5a.5.5 0 0 0-1 0v3.975a.5.5 0 0 0 .5.5H4.5a.5.5 0 0 0 0-1H1.732l4.096-4.096a.5.5 0 0 0 0-.707zm4.344 0a.5.5 0 0 1 .707 0l4.096 4.096V11.5a.5.5 0 1 1 1 0v3.975a.5.5 0 0 1-.5.5H11.5a.5.5 0 0 1 0-1h2.768l-4.096-4.096a.5.5 0 0 1 0-.707zm0-4.344a.5.5 0 0 0 .707 0l4.096-4.096V4.5a.5.5 0 1 0 1 0V.525a.5.5 0 0 0-.5-.5H11.5a.5.5 0 0 0 0 1h2.768l-4.096 4.096a.5.5 0 0 0 0 .707zm-4.344 0a.5.5 0 0 1-.707 0L1.025 1.732V4.5a.5.5 0 0 1-1 0V.525a.5.5 0 0 1 .5-.5H4.5a.5.5 0 0 1 0 1H1.732l4.096 4.096a.5.5 0 0 1 0 .707z"/>
                                </svg>
                            </a>
                        </div>`).join('')}
                    </div>
                </div>
                ${product.description ? `<p style="color: #666; font-size: 0.9rem; margin-bottom: 0.5rem;">${product.description}</p>` : ''}
                <span class="price">${product.price.toFixed(2)} €</span>
                
                <div class="product-options">
                    <div class="option-group">
                        <label>Menge</label>
                        <input type="number" id="qty-${product.id}" value="1" min="1" class="qty-input">
                    </div>
                    
                    <div class="option-group">
                        <label>Farbe</label>
                        <div class="color-preview-container">
                            <select id="color-${product.id}" onchange="updateColorPreview(this, '${product.id}')">
                                ${colors.map(c => `<option value="${c.value}">${c.name}</option>`).join('')}
                            </select>
                            <div id="preview-${product.id}" class="color-preview preview-blue"></div>
                        </div>
                    </div>

                    <div id="custom-color-wrapper-${product.id}" class="option-group" style="display: none;">
                        <label style="color: var(--primary-blue);">Ihre Wunschfarbe:</label>
                        <input type="text" id="custom-color-input-${product.id}" placeholder="Welche Farbe möchten Sie?" class="qty-input">
                        <div class="warning-msg">
                            <strong>Hinweis:</strong> Diese Farbe muss ggf. extra bestellt werden. Dadurch können zusätzliche Kosten und Wartezeiten entstehen.
                        </div>
                    </div>
                </div>

                <button class="add-btn" onclick="addToCart('${product.id}')">
                    In den Warenkorb
                </button>
            </div>
            `;
        }

        return `
        <div class="product-card">
            <h3>${product.name}</h3>
            ${product.description ? `<p style="color: #666; font-size: 0.9rem; margin-bottom: 0.5rem;">${product.description}</p>` : ''}
            <span class="price">${product.price.toFixed(2)} €</span>
            
            <div class="product-options">
                <div class="option-group">
                    <label>Menge</label>
                    <input type="number" id="qty-${product.id}" value="1" min="1" class="qty-input">
                </div>
                
                <div class="option-group">
                    <label>Farbe</label>
                    <div class="color-preview-container">
                        <select id="color-${product.id}" onchange="updateColorPreview(this, '${product.id}')">
                            ${colors.map(c => `<option value="${c.value}">${c.name}</option>`).join('')}
                        </select>
                        <div id="preview-${product.id}" class="color-preview preview-blue"></div>
                    </div>
                </div>

                <div id="custom-color-wrapper-${product.id}" class="option-group" style="display: none;">
                    <label style="color: var(--primary-blue);">Ihre Wunschfarbe:</label>
                    <input type="text" id="custom-color-input-${product.id}" placeholder="Welche Farbe möchten Sie?" class="qty-input">
                    <div class="warning-msg">
                        <strong>Hinweis:</strong> Diese Farbe muss ggf. extra bestellt werden. Dadurch können zusätzliche Kosten und Wartezeiten entstehen.
                    </div>
                </div>
            </div>

            <button class="add-btn" onclick="addToCart('${product.id}')">
                In den Warenkorb
            </button>
        </div>
    `}).join('');
}

// Update the little color circle when selection changes
window.updateColorPreview = function (select, id) {
    const preview = document.getElementById(`preview-${id}`);
    const customWrapper = document.getElementById(`custom-color-wrapper-${id}`);

    preview.className = `color-preview preview-${select.value}`;

    if (select.value === 'custom') {
        customWrapper.style.display = 'block';
    } else {
        customWrapper.style.display = 'none';
        // Clear input when hiding to avoid confusion? Optional.
    }
};

// Navigation Logic (SPA)
function setupNavigation() {
    const links = document.querySelectorAll('.nav-link, .cart-icon-container');
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            if (link.tagName === 'A') { // Check if it's our nav links, not generic
                e.preventDefault();
                const targetId = link.getAttribute('data-target') || 'cart'; // Default to cart if icon clicked
                showSection(targetId);
            }
            // For cart icon container, explicit check
            if (link.classList.contains('cart-icon-container')) {
                e.preventDefault();
                showSection('cart');
            }
        });
    });
}

function showSection(id) {
    // Hide all sections
    document.querySelectorAll('section').forEach(sec => {
        sec.classList.remove('active');
        if (sec.style.display !== 'none') sec.style.display = 'none'; // Ensure hidden
    });

    // Show target section(s)
    // Note: Home is special, it's a section.
    const target = document.getElementById(id);
    if (target) {
        target.style.display = (id === 'home') ? 'flex' : 'block';
        setTimeout(() => target.classList.add('active'), 10); // Small delay for fade in
    }

    // Update active nav link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('data-target') === id) link.classList.add('active');
    });

    if (id === 'cart') renderCart();
}

// Cart Logic for Normal Items
window.addToCart = function (productId) {
    const product = products.find(p => p.id === productId);
    const qtyInput = document.getElementById(`qty-${productId}`);
    let qty = parseInt(qtyInput.value);

    if (isNaN(qty) || qty < 1) {
        alert("Bitte geben Sie eine gültige Menge ein (mindestens 1).");
        return;
    }

    const colorSelect = document.getElementById(`color-${productId}`);
    let colorVal = colorSelect.value;
    let colorName = colors.find(c => c.value === colorVal).name;

    // Handle Custom Color
    if (colorVal === 'custom') {
        const customInput = document.getElementById(`custom-color-input-${productId}`);
        const customColorName = customInput.value.trim();

        if (customColorName.length < 2) {
            alert("Bitte geben Sie Ihre Wunschfarbe ein.");
            customInput.focus();
            return;
        }
        colorName = `Wunschfarbe: ${customColorName}`;
        // Unique ID for cart separation (otherwise 'custom' stacks)
        colorVal = `custom-${customColorName.toLowerCase().replace(/\s/g, '-')}`;
    }

    const existingItem = cart.find(item => item.id === productId && item.color === colorVal && !item.isCustom);

    if (existingItem) {
        existingItem.qty += qty;
    } else {
        cart.push({
            id: productId,
            name: product.name,
            price: product.price,
            qty: qty,
            color: colorVal,
            colorName: colorName,
            isCustom: false
        });
    }

    alert(`${qty}x ${product.name} (${colorName}) wurde zum Warenkorb hinzugefügt.`);
    updateCartIcon();
};

// Cart Logic for Custom Items
window.addCustomToCart = function (productId) {
    const product = products.find(p => p.id === productId);
    const fromVal = document.getElementById(`custom-from-${productId}`).value;
    const toVal = document.getElementById(`custom-to-${productId}`).value;
    const descVal = document.getElementById(`custom-desc-${productId}`).value;

    if (!fromVal || !toVal || !descVal) {
        alert("Bitte füllen Sie alle Felder für den Auftrag aus.");
        return;
    }

    cart.push({
        id: productId,
        name: product.name,
        price: 0, // Custom items have 0 price initially as per request/logic
        qty: 1,
        isCustom: true,
        customFrom: fromVal,
        customTo: toVal,
        customDesc: descVal
    });

    alert(`Auftrag wurde zum Warenkorb hinzugefügt.`);

    // Clear inputs
    document.getElementById(`custom-from-${productId}`).value = '';
    document.getElementById(`custom-to-${productId}`).value = '';
    document.getElementById(`custom-desc-${productId}`).value = '';

    updateCartIcon();
}

window.removeFromCart = function (index) {
    cart.splice(index, 1);
    renderCart(); // Re-render cart to show updates
    updateCartIcon();
};

function updateCartIcon() {
    const totalQty = cart.reduce((sum, item) => sum + item.qty, 0);
    document.getElementById('cart-count').innerText = totalQty;
}

function renderCart() {
    const container = document.getElementById('cart-items-container');
    const summaryContainer = document.getElementById('cart-summary');

    if (cart.length === 0) {
        container.innerHTML = '<p>Ihr Warenkorb ist leer.</p>';
        summaryContainer.style.display = 'none';
        return;
    }

    summaryContainer.style.display = 'block';

    container.innerHTML = cart.map((item, index) => {
        if (item.isCustom) {
            return `
            <div class="cart-item">
                <div class="cart-item-details">
                    <h4>${item.name}</h4>
                    <div class="cart-item-info">
                        <strong>Auftrag:</strong> ${item.customDesc}<br>
                        <strong>Von:</strong> ${item.customFrom} | <strong>Zu:</strong> ${item.customTo}
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap: 1rem;">
                    <strong>Preis auf Anfrage</strong>
                    <button class="remove-btn" onclick="removeFromCart(${index})" title="Entfernen">
                        Remove
                    </button>
                </div>
            </div>`;
        } else {
            return `
            <div class="cart-item">
                <div class="cart-item-details">
                    <h4>${item.name}</h4>
                    <div class="cart-item-info">Menge: ${item.qty} | Farbe: ${item.colorName} | Einzelpreis: ${item.price.toFixed(2)}€</div>
                </div>
                <div style="display:flex; align-items:center; gap: 1rem;">
                    <strong>${(item.price * item.qty).toFixed(2)} €</strong>
                    <button class="remove-btn" onclick="removeFromCart(${index})" title="Entfernen">
                        Remove
                    </button>
                </div>
            </div>`;
        }
    }).join('');

    // Update icons in HTML string (hacky reuse of SVG separately to keep code clean above)
    // Fixed the SVG issue by just using text "Remove" or simplified SVG above. 
    // Let's perform a quick replacement to ensure the trash icon is there if nice.
    // Actually, I just used text "Remove" to avoid big SVG block in map. 
    // Let's stick the SVG back in for polish.
    const trashSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 16 16"><path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/><path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/></svg>`;
    container.querySelectorAll('.remove-btn').forEach(btn => btn.innerHTML = trashSvg);


    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    const total = subtotal + SHIPPING_COST;

    document.getElementById('subtotal').innerText = subtotal.toFixed(2) + ' €';
    document.getElementById('shipping').innerText = SHIPPING_COST.toFixed(2) + ' €';
    document.getElementById('total-sum').innerText = total.toFixed(2) + ' €';
}

window.checkout = function () {
    if (cart.length === 0) return;

    // 1. Name Validation
    let name = "";
    while (!name || name.trim().length < 2) {
        name = prompt("Bitte geben Sie Ihren vollständigen Namen ein (Pflichtfeld):");
        if (name === null) return; // Cancelled
        if (!name || name.trim().length < 2) alert("Bitte geben Sie einen gültigen Namen ein.");
    }

    // 2. Street/Address Validation
    let address = "";
    while (!address || address.trim().length < 5) {
        address = prompt("Bitte geben Sie Ihre Straße und Hausnummer ein (Pflichtfeld):");
        if (address === null) return;
        if (!address || address.trim().length < 5) alert("Bitte geben Sie eine gültige Straße ein.");
    }

    // 3. PLZ Validation (Simple numeric check)
    let zip = "";
    while (!zip || zip.trim().length < 4 || isNaN(zip.trim())) {
        zip = prompt("Bitte geben Sie Ihre Postleitzahl ein (Pflichtfeld):");
        if (zip === null) return;
        if (!zip || zip.trim().length < 4 || isNaN(zip.trim())) alert("Bitte geben Sie eine gültige Postleitzahl ein.");
    }

    // 4. City Validation
    let city = "";
    while (!city || city.trim().length < 2) {
        city = prompt("Bitte geben Sie Ihren Ort ein (Pflichtfeld):");
        if (city === null) return;
        if (!city || city.trim().length < 2) alert("Bitte geben Sie einen gültigen Ort ein.");
    }

    // Generate Unique Order ID (Timestamp + Random)
    const orderId = generateOrderId();

    // Build Email Body
    let body = `Hallo Druckbau Team,\n\nIch möchte folgende Bestellung aufgeben:\nBestellnummer: ${orderId}\n\nKundendaten:\nName: ${name}\nAdresse: ${address}\nPLZ/Ort: ${zip} ${city}\n\nBestellung:\n`;

    cart.forEach(item => {
        if (item.isCustom) {
            body += `- [AUFTRAGSARBEIT] ${item.name}\n  Von: ${item.customFrom}\n  Zu: ${item.customTo}\n  Info: ${item.customDesc}\n`;
        } else {
            body += `- ${item.qty}x ${item.name} (${item.colorName}) - ${(item.price * item.qty).toFixed(2)} €\n`;
        }
    });

    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    const total = subtotal + SHIPPING_COST;

    body += `\nZwischensumme: ${subtotal.toFixed(2)} € (exkl. Auftragsarbeiten)\n`;
    body += `Versand: ${SHIPPING_COST.toFixed(2)} €\n`;
    body += `Gesamt: ${total.toFixed(2)} € (zzgl. eventueller Auftragskosten)\n\n`;
    body += `Bitte senden Sie mir eine Bestätigung.`;

    // Subject with Order ID
    const subject = `Bestellung ${orderId} von ${name}`;

    const mailtoLink = `mailto:druckbau@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

    // Open Mail Client
    window.location.href = mailtoLink;

    // Redirect to Success Page similar to contact form
    // This gives the user feedback that something happened and they should check their mail client
    setTimeout(() => {
        window.location.href = 'success.html';
    }, 1000);
};

// Helper to generate a unique readable Order ID
function generateOrderId() {
    const now = new Date();
    // Format: DB-YYYYMMDD-XXXX (4 random digits)
    const dateStr = now.getFullYear().toString() +
        (now.getMonth() + 1).toString().padStart(2, '0') +
        now.getDate().toString().padStart(2, '0');
    const randomSuffix = Math.floor(1000 + Math.random() * 9000); // 1000-9999
    return `DB-${dateStr}-${randomSuffix}`;
}

// Contact Form Logic
window.handleContact = function () {
    const name = document.getElementById('contact-name').value;
    const email = document.getElementById('contact-email').value;
    const orderId = document.getElementById('contact-order-id').value;
    const message = document.getElementById('contact-message').value;

    // Strict validation
    if (!name || name.trim().length < 2) {
        alert("Bitte geben Sie Ihren Namen ein.");
        return;
    }
    if (!email || !email.includes('@') || email.trim().length < 5) {
        alert("Bitte geben Sie eine gültige E-Mail-Adresse ein.");
        return;
    }
    if (!orderId || orderId.trim().length < 2) {
        alert("Bitte geben Sie eine Bestellnummer ein.");
        return;
    }
    if (!message || message.trim().length < 10) {
        alert("Bitte geben Sie eine Nachricht ein (mindestens 10 Zeichen).");
        return;
    }

    // Priority Check Logic
    const urgentKeywords = [
        'dringend', 'sofort', 'defekt', 'kaputt', 'beschwerde', 'problem', 'hilfe', 'eilig', 'wichtig', 'notfall',
        'reklamation', 'rückerstattung', 'stornierung', 'frist', 'deadline', 'fehler', 'falsch', 'nicht erhalten',
        'vermisst', 'beschädigt', 'kaput', 'geld zurück', 'schaden', 'anzeige', 'mahnung'
    ];
    const mediumKeywords = ['frage', 'bestellung', 'status', 'wann', 'angebot', 'termin', 'lieferzeit', 'versand'];

    let subject = "Anfrage über Webseite";
    const lowerMsg = message.toLowerCase();

    // Check for high priority
    const isUrgent = urgentKeywords.some(keyword => lowerMsg.includes(keyword));
    // Check for medium priority if not urgent
    const isMedium = !isUrgent && mediumKeywords.some(keyword => lowerMsg.includes(keyword));

    if (isUrgent) {
        subject = "[HOHE PRIORITÄT] " + subject;
    } else if (isMedium) {
        subject = "[MITTLERE PRIORITÄT] " + subject;
    }

    // Construct Email Body
    let bodyHeader = `Name: ${name}\nE-Mail: ${email}\n`;
    if (orderId && orderId.trim() !== "") {
        bodyHeader += `Bestellnummer: ${orderId}\n`;
    }
    bodyHeader += `\n--------------------------------\n\n`;

    const body = bodyHeader + message;

    // Open mail client
    window.location.href = `mailto:druckbau@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

    // Redirect to success page after a short delay to allow mail client to open
    setTimeout(() => {
        window.location.href = 'success.html';
    }, 1000);
}

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    init();

    // Add lightbox to body (only on main page, not gallery page)
    if (!document.getElementById('gallery-app')) {
        const lightbox = document.createElement('div');
        lightbox.id = 'lightbox';
        lightbox.className = 'lightbox';
        // Use event listener for better control
        lightbox.addEventListener('click', (e) => {
            // Close if clicking the background (lightbox div) or the close button
            if (e.target === lightbox || e.target.classList.contains('close-lightbox')) {
                closeLightbox();
            }
        });

        lightbox.innerHTML = '<span class="close-lightbox">&times;</span><img class="lightbox-content" id="lightbox-img">';
        document.body.appendChild(lightbox);
    }
});

// Global Event Delegation for Gallery Items
document.addEventListener('click', (e) => {
    // Check if clicked element is or is inside a gallery-item
    const galleryItem = e.target.closest('.gallery-item');
    if (galleryItem) {
        const src = galleryItem.getAttribute('data-lightbox-src');
        if (src) {
            openLightbox(src);
        }
    }
});

// Explicitly define global functions for the onclick handlers in HTML
window.openLightbox = function (src) {
    const lightbox = document.getElementById('lightbox');
    const img = document.getElementById('lightbox-img');
    if (lightbox && img) {
        img.src = src;
        lightbox.style.display = 'flex';
    }
}

window.closeLightbox = function () {
    const lightbox = document.getElementById('lightbox');
    if (lightbox) {
        lightbox.style.display = 'none';
    }
}

